const { Sequelize } = require('sequelize');
const path = require('path');

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, '..', 'database', 'database.sqlite'),
  logging: false
});

const Item = require('./Item')(sequelize);

module.exports = { sequelize, Item };
