const express = require('express');
const router = express.Router();
const { Item } = require('../models');

router.get('/', async (req, res) => {
  const items = await Item.findAll({ order: [['createdAt', 'DESC']] });
  res.render('index', { items, title: 'Lista' });
});

module.exports = router;
