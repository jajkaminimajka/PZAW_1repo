const express = require('express');
const router = express.Router();
const { Item } = require('../models');

router.get('/new', (req, res) => {
  res.render('new', { title: 'Nowy' });
});

router.post('/', async (req, res) => {
  const { title, description, quantity } = req.body;
  await Item.create({ title, description, quantity });
  res.redirect('/');
});

router.get('/:id', async (req, res) => {
  const item = await Item.findByPk(req.params.id);
  res.render('show', { item, title: item.title });
});

router.get('/:id/edit', async (req, res) => {
  const item = await Item.findByPk(req.params.id);
  res.render('edit', { item, title: 'Edycja' });
});

router.put('/:id', async (req, res) => {
  const item = await Item.findByPk(req.params.id);
  const { title, description, quantity } = req.body;
  await item.update({ title, description, quantity });
  res.redirect('/');
});

router.delete('/:id', async (req, res) => {
  const item = await Item.findByPk(req.params.id);
  await item.destroy();
  res.redirect('/');
});

module.exports = router;
